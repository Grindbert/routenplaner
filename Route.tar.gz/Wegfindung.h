#include<vector>
#include<QPointF>
#include<queue>		//für die Priority-Queue
#include<limits>	//für das Maximum von float
#include<cmath>

#include"Knoten.h"

std::vector<int> Wegfindung(std::vector<Knoten>*, QPointF, QPointF, bool*, float*);
